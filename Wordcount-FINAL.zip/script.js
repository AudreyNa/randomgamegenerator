// There are two pieces of code. One  for the automatic update one and the other for the button. The button will not appear if I have my automatic code. Both codes work. If the code has some unforseen problem there will be a comment at the very bottom.
//this page only has the automatic one.

//automatic
function automatic(){
  var a = document.getElementById("box").value;
	console.log(a);
  var result=a.split(" ")
  console.log (result)
  // in python result.remove(" ")

  var numofwords=result.length
  console.log (numofwords)
  //for i in result:
  //        if x = " ":
  //        numofwords= numofwords-1
  //        else:
  //        numofwords= numofwords+0

  document.getElementById("wordCount").innerHTML=numofwords
}
// one bug need to fix : make empty set after initial run. When run the first time, it is automatically zero because the set hasn't been created. After you run it the count becomes one even if there isn't anything in it because it has an empty item in it. This bug doesn't affect the count of the number. The count will still be accurate except when there are no words.