//HTML code
<button onclick="countWords()">Update Word Count</button>
//button code
function countWords() {
	var a = document.getElementById("box").value;
	console.log(a);

  var result=a.split(" ")
  console.log (result)
  // in python result.remove(" ")

  var numofwords=result.length
  console.log (numofwords)
    //for i in result:
  //        if x = " ":
  //        numofwords= numofwords-1
  //        else:
  //        numofwords= numofwords+0

  document.getElementById("wordCount").innerHTML=numofwords
}