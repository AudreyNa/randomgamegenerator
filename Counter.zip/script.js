let k = 0;

function check() {
  if (k > 0) {
    document.getElementById("value").style.color = "green";
  }
  else if (k < 0) {
    document.getElementById("value").style.color = "red";
  }
  else {
    document.getElementById("value").style.color = "hsl(209, 61%, 16%)";
  }
}

function decrease() {
  k--;
  document.getElementById("value").innerText = k;
  check();
}

function reset() {
  k = 0;
  document.getElementById("value").innerText = k;
  check();
}

function increase() {
  k++;
  document.getElementById("value").innerText = k;
  check();
}