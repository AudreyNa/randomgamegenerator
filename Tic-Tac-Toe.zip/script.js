// see tic-tac-toe tryout for notes
let gameActive = true;
let gameOver = false;
var x = 0;
var y = 0;
var z = 0;

array = ["0", "1", "2", "3", "4", "5", "6", "7", "8"]

let arr = ["", "", "", "", "", "", "", "", ""]
function Xresponse() {
  if (gameOver == false) {
    var randomnumber = Math.floor(Math.random() * array.length);
    if (array.length == 0) {
    }
    else {
      document.getElementById(array[randomnumber]).innerHTML = "X";
      randomnumber = randomnumber.toString()
      arr.splice(array[randomnumber], 1, "X")
      array.splice(randomnumber, 1)
      document.getElementById("turn").innerHTML = "Turn: X"
      var b = CheckWin()
    }
  }
}

function reply_click(clicked_id) {
  if (gameOver == false) {
    if (array.includes(clicked_id) == true) {
      document.getElementById(clicked_id).innerHTML = "O";
      arr.splice(clicked_id, 1, "O")
      array.splice(array.indexOf(clicked_id), 1)
      document.getElementById("turn").innerHTML = "Turn: O"
      var d = Xresponse();
      var b = CheckWin()
      if ((b == "Won") || (b == "Lost") || (b == "Draw")) {
        gameOver = true;
      }
    }
    else {}
  }
}

const winningConditions = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  [0, 4, 8],
  [2, 4, 6]
];

function CheckWin() {
  let roundWon = false;

  for (let i = 0; i <= 7; i++) {
    const winCondition = winningConditions[i];
    var a = arr[winCondition[0]];
    let b = arr[winCondition[1]];
    let c = arr[winCondition[2]];
    if (a === '' || b === '' || c === '') {
      continue;
    }
    if (a === b && b === c) {
      roundWon = true;
      break
    }
  }
  console.log(a)
  if ((roundWon == true) && (a == "O")) {

    document.getElementById("wintimes").innerHTML = ("Wins-" + (x + 1));
    document.getElementById("message").innerHTML = "You won!";
    gameActive = false;
    x = x + 1
    return ("Won");
  }
  else if ((roundWon == true) && (a == "X")) {
    document.getElementById("losetimes").innerHTML = ("Losses-" + (y + 1));
    document.getElementById("message").innerHTML = "You lost!";
    gameActive = false;
    y = y + 1
    return ("Lost");

  }

  let roundDraw = !arr.includes("");
  if (roundDraw) {
    document.getElementById("drawtimes").innerHTML = ("Draws-" + (z + 1));
    document.getElementById("message").innerHTML = "It's a tie!";
    z = z + 1
    gameActive = false;
    return ("Draw");
  }
}


function restartGame() {
  array = ["0", "1", "2", "3", "4", "5", "6", "7", "8"]
  for (let d = 0; d <= 8; d++) {
    document.getElementById(d).innerHTML = ""
  }
  gameActive = true;
  gameOver = false;
  document.getElementById("turn").innerHTML = "Turn: O"
  arr = ["", "", "", "", "", "", "", "", ""]
  document.getElementById("message").innerHTML = ""
}


function fu() {
  window.location = "https://bored-button.audreyna.repl.co/"
}