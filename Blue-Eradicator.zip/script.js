


function myFunction() {
  document.getElementById('myImage').src = "img/load.gif"
  setTimeout(() => { var d = bluechanger(); }, 2000);

}
function bluechanger() {
  window.location=randomlinks[Math.floor (Math.random()*randomlinks.length)]
}


var randomlinks = new Array()
randomlinks[0] = "https://rock-paper-scissor-stone.audreyna.repl.co/"
randomlinks[1] = "https://tic-tac-toe.audreyna.repl.co/"
randomlinks[2]="https://replit.com/@AudreyNa/Hangman#main.py"
