




function myFunction() {
  setTimeout(() => { var d = elitenoob(); }, 220);
}
function elitenoob() {
  var x = document.getElementById("myDIV");
  var y = document.getElementById("LP");
  if (x.style.display === "none") {
    x.style.display = "block";
    y.style.display = "none"
  } else {
    x.style.display = "none";
    y.style.display = "none"
  }
}

function disOppMove() {
  var mo = document.getElementById("hide");
  var po = document.getElementById("computer");
  if (po.style.display === "none") {
    po.style.display = "inline-block";
    mo.style.display = "inline-block"
  } else {
    po.style.display = "inline-block";
    mo.style.display = "inline-block"
  }
}


function restart() {
  var obj = document.getElementById("paper");
  var job = document.getElementById("rock");
  var boj = document.getElementById("scissors");
  if (obj.style.display === "none") {
    obj.style.display = "inline-block";
    job.style.display = "inline-block"
  }
  else {
    obj.style.display = "inline-block";
    job.style.display = "inline-block"
  }
  if (obj.style.display === "none") {
    boj.style.display = "inline-block";
    job.style.display = "inline-block"
  } else {
    boj.style.display = "inline-block";
    job.style.display = "inline-block"
  }
  if (obj.style.display === "none") {
    obj.style.display = "inline-block";
    boj.style.display = "inline-block"
  } else {
    obj.style.display = "inline-block";
    boj.style.display = "inline-block"

  }
}


function returnlol() {
  var mo = document.getElementById("hide");
  var po = document.getElementById("computer");
  if (po.style.display === "none") {
    po.style.display = "none";
    mo.style.display = "none"
  } else {
    po.style.display = "none";
    mo.style.display = "none"
  }
}



function computerMove() {
  var randomNum = Math.random() * 3;
  if (randomNum < 1) {
    return "rock";
  } else if (randomNum < 2) {
    return "paper";
  } else {
    return "scissors";
  }
}
// Do not edit above this point!
var a = 0
var b = 0
var c = 0
function play(playerMove) {
  console.log("\nPlayer: " + playerMove);
  var compMove = computerMove();
  console.log("\nComputer Player: " + compMove);
  var combo = compMove.concat(playerMove);
  console.log(combo);


  var obj = document.getElementById("paper");
  var job = document.getElementById("rock");
  var boj = document.getElementById("scissors");
  if (playerMove == "scissors") {
    if (obj.style.display === "none") {
      obj.style.display = "none";
      job.style.display = "none"
    } else {
      obj.style.display = "none";
      job.style.display = "none"
    }
  }
  else if (playerMove == "paper") {
    if (obj.style.display === "none") {
      boj.style.display = "none";
      job.style.display = "none"
    } else {
      boj.style.display = "none";
      job.style.display = "none"
    }
  }
  else if (playerMove == "rock") {
    if (obj.style.display === "none") {
      obj.style.display = "none";
      boj.style.display = "none"
    } else {
      obj.style.display = "none";
      boj.style.display = "none"
    }
  }


  setTimeout(() => { var d = restart(); returnlol(); }, 1000);










  if ((combo == "scissorsrock") || (combo == "rockpaper") || (combo == "paperscissors")) {
    var end = "You won!"
    console.log(end)
  }
  else if ((combo == "rockscissors") || (combo == "paperrock") || (combo == "scissorspaper")) {
    var end = "You lost!"
    console.log(end)
  }
  else {
    var end = "It was a draw."
    console.log(end)
  }

  document.getElementById("youPlayed").innerHTML = ("Your Move (Left): " + playerMove)

  document.getElementById("computerPlayed").innerHTML = ("Computer Move (Right): " + compMove)

  document.getElementById("didYouWin").innerHTML = end
  if (end == "It was a draw.") {
    a = a + 1
    console.log(a)
    document.getElementById("draws").innerHTML = a
  }
  else if (end == "You lost!") {
    b = b + 1
    console.log(b)
    document.getElementById("losses").innerHTML = b
  }
  else {
    c = c + 1
    console.log(c)
    document.getElementById("wins").innerHTML = c
  }
  if (compMove == "rock") {
    document.getElementById("computer").src = "image/rock.png";
    disOppMove()
  }
  else if (compMove == "paper") {
    document.getElementById("computer").src = "image/paper.png";
    disOppMove()
  }
  else {
    document.getElementById("computer").src = "image/scissors.png";
    disOppMove()
  }
}


function Restart() {
  a = 0
  b = 0
  c = 0
  document.getElementById("wins").innerHTML = c
  document.getElementById("draws").innerHTML = a
  document.getElementById("losses").innerHTML = b
  document.getElementById("youPlayed").innerHTML = ("")
  document.getElementById("computerPlayed").innerHTML = ("")
  document.getElementById("didYouWin").innerHTML = ""
}

function fu(){
  window.location="https://bored-button.audreyna.repl.co/"
}